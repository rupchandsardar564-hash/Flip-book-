import { useState, useRef, useCallback, useEffect } from "react";

declare global {
  interface Window {
    pdfjsLib: any;
  }
}

interface PageData {
  dataUrl: string;
  width: number;
  height: number;
}

function App() {
  const [pages, setPages] = useState<PageData[]>([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [fileName, setFileName] = useState("");
  const [generating, setGenerating] = useState(false);
  const [downloadReady, setDownloadReady] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const downloadLinkRef = useRef<HTMLAnchorElement>(null);

  useEffect(() => {
    if (window.pdfjsLib) {
      window.pdfjsLib.GlobalWorkerOptions.workerSrc =
        "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.min.js";
    }
  }, []);

  // Cleanup download URL on unmount
  useEffect(() => {
    return () => {
      if (downloadUrl) {
        URL.revokeObjectURL(downloadUrl);
      }
    };
  }, [downloadUrl]);

  const handleFileUpload = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      setFileName(file.name.replace(".pdf", ""));
      setLoading(true);
      setPages([]);
      setCurrentPage(0);
      setProgress(0);
      setDownloadReady(false);
      if (downloadUrl) {
        URL.revokeObjectURL(downloadUrl);
        setDownloadUrl("");
      }

      try {
        const reader = new FileReader();
        reader.onload = async function () {
          try {
            const typedarray = new Uint8Array(this.result as ArrayBuffer);
            const pdf = await window.pdfjsLib.getDocument(typedarray).promise;
            const numPages = pdf.numPages;
            setTotalPages(numPages);

            const loadedPages: PageData[] = [];

            for (let i = 1; i <= numPages; i++) {
              const page = await pdf.getPage(i);
              const scale = 1.5;
              const viewport = page.getViewport({ scale });
              const canvas = document.createElement("canvas");
              const context = canvas.getContext("2d")!;
              canvas.height = viewport.height;
              canvas.width = viewport.width;

              await page.render({ canvasContext: context, viewport }).promise;

              const dataUrl = canvas.toDataURL("image/jpeg", 0.8);
              loadedPages.push({
                dataUrl,
                width: viewport.width,
                height: viewport.height,
              });

              setProgress(Math.round((i / numPages) * 100));
            }

            setPages(loadedPages);
            setLoading(false);
          } catch (err) {
            console.error("PDF processing error:", err);
            alert("PDF প্রসেস করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।");
            setLoading(false);
          }
        };

        reader.readAsArrayBuffer(file);
      } catch (err) {
        console.error("File read error:", err);
        alert("ফাইল পড়তে সমস্যা হয়েছে।");
        setLoading(false);
      }
    },
    [downloadUrl]
  );

  const nextPage = useCallback(() => {
    setCurrentPage((p) => (p < pages.length - 1 ? p + 1 : p));
  }, [pages.length]);

  const prevPage = useCallback(() => {
    setCurrentPage((p) => (p > 0 ? p - 1 : p));
  }, []);

  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "ArrowDown") {
        nextPage();
      } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
        prevPage();
      }
    },
    [nextPage, prevPage]
  );

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  // Touch/swipe support
  const touchStartX = useRef(0);
  useEffect(() => {
    const handleTouchStart = (e: TouchEvent) => {
      touchStartX.current = e.changedTouches[0].screenX;
    };
    const handleTouchEnd = (e: TouchEvent) => {
      const diff = e.changedTouches[0].screenX - touchStartX.current;
      if (Math.abs(diff) > 50) {
        if (diff < 0) nextPage();
        else prevPage();
      }
    };
    window.addEventListener("touchstart", handleTouchStart);
    window.addEventListener("touchend", handleTouchEnd);
    return () => {
      window.removeEventListener("touchstart", handleTouchStart);
      window.removeEventListener("touchend", handleTouchEnd);
    };
  }, [nextPage, prevPage]);

  const generateDownload = async () => {
    if (pages.length === 0) return;
    setGenerating(true);

    try {
      // Build images array as a separate string to avoid template literal issues
      const imagesArrayStr = "[" + pages.map((p) => '"' + p.dataUrl.replace(/"/g, '\\"') + '"').join(",") + "]";

      const title = fileName || "Flipbook";
      const numPagesTotal = pages.length;

      const htmlParts: string[] = [];

      htmlParts.push(`<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${title} - Offline Flipbook</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);min-height:100vh;font-family:'Segoe UI',Arial,sans-serif;color:#fff;display:flex;flex-direction:column;align-items:center;overflow-x:hidden;user-select:none}
h1{margin:15px 0 5px;font-size:1.5rem;background:linear-gradient(90deg,#f093fb,#f5576c);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.info{font-size:0.85rem;color:#aaa;margin-bottom:10px}
.viewer-wrap{position:relative;width:92%;max-width:800px;margin:10px auto;flex:1;display:flex;align-items:center;justify-content:center}
.viewer{position:relative;width:100%;border-radius:10px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,0.6);background:#222}
.page-box{position:relative;width:100%;padding-bottom:75%;overflow:hidden}
.page{position:absolute;top:0;left:0;width:100%;height:100%;transform-origin:left center;transition:transform 0.8s cubic-bezier(0.645,0.045,0.355,1);backface-visibility:hidden;overflow:hidden}
.page img{width:100%;height:100%;object-fit:contain;background:#fff}
.page.flipped{transform:rotateY(-180deg)}
.touch-zone{position:absolute;top:0;width:40%;height:100%;z-index:10;cursor:pointer}
.touch-left{left:0}
.touch-right{right:0}
.controls{display:flex;align-items:center;gap:15px;margin:15px 0 20px;flex-wrap:wrap;justify-content:center}
.btn{padding:10px 28px;border:none;border-radius:25px;font-size:1rem;cursor:pointer;transition:all 0.3s;font-weight:600;color:#fff}
.btn-prev{background:linear-gradient(135deg,#667eea,#764ba2)}
.btn-next{background:linear-gradient(135deg,#764ba2,#f5576c)}
.btn:hover{transform:translateY(-2px);box-shadow:0 5px 20px rgba(102,126,234,0.4)}
.btn:disabled{opacity:0.3;cursor:not-allowed;transform:none;box-shadow:none}
.page-info{font-size:1.1rem;min-width:100px;text-align:center;background:rgba(255,255,255,0.1);padding:8px 16px;border-radius:20px}
.hint{font-size:0.75rem;color:#666;margin-bottom:15px;text-align:center;padding:0 10px}
</style>
</head>
<body>
<h1>📖 ${title}</h1>
<p class="info">মোট পৃষ্ঠা: ${numPagesTotal}</p>
<div class="viewer-wrap">
<div class="viewer">
<div class="page-box" id="viewer"></div>
<div class="touch-zone touch-left" onclick="prevPage()"></div>
<div class="touch-zone touch-right" onclick="nextPage()"></div>
</div>
</div>
<div class="controls">
<button class="btn btn-prev" id="prevBtn" onclick="prevPage()">◀ আগের পৃষ্ঠা</button>
<span class="page-info" id="pageInfo">1 / ${numPagesTotal}</span>
<button class="btn btn-next" id="nextBtn" onclick="nextPage()">পরের পৃষ্ঠা ▶</button>
</div>
<p class="hint">← → Arrow keys দিয়ে পৃষ্ঠা উল্টান | বাম/ডান পাশে ক্লিক করুন | মোবাইলে সোয়াইপ করুন</p>
<script>
var images = `);

      htmlParts.push(imagesArrayStr);

      htmlParts.push(`;
var cur=0;
var total=images.length;
var viewer=document.getElementById('viewer');
var info=document.getElementById('pageInfo');
var pb=document.getElementById('prevBtn');
var nb=document.getElementById('nextBtn');

function init(){
  for(var i=0;i<total;i++){
    var d=document.createElement('div');
    d.className='page';
    d.id='p'+i;
    d.style.zIndex=total-i;
    var img=document.createElement('img');
    img.src=images[i];
    d.appendChild(img);
    viewer.appendChild(d);
  }
  upd();
}

function nextPage(){
  if(cur<total-1){
    var p=document.getElementById('p'+cur);
    if(p)p.classList.add('flipped');
    cur++;
    upd();
  }
}

function prevPage(){
  if(cur>0){
    cur--;
    var p=document.getElementById('p'+cur);
    if(p)p.classList.remove('flipped');
    upd();
  }
}

function upd(){
  info.textContent=(cur+1)+' / '+total;
  pb.disabled=cur===0;
  nb.disabled=cur===total-1;
}

document.addEventListener('keydown',function(e){
  if(e.key==='ArrowRight'||e.key==='ArrowDown')nextPage();
  else if(e.key==='ArrowLeft'||e.key==='ArrowUp')prevPage();
});

var tsx=0;
document.addEventListener('touchstart',function(e){tsx=e.changedTouches[0].screenX;});
document.addEventListener('touchend',function(e){
  var d=e.changedTouches[0].screenX-tsx;
  if(Math.abs(d)>50){if(d<0)nextPage();else prevPage();}
});

init();
</script>
</body>
</html>`);

      const fullHtml = htmlParts.join("");
      const blob = new Blob([fullHtml], { type: "text/html;charset=utf-8" });

      // Revoke old URL if exists
      if (downloadUrl) {
        URL.revokeObjectURL(downloadUrl);
      }

      const url = URL.createObjectURL(blob);
      setDownloadUrl(url);
      setDownloadReady(true);
      setGenerating(false);
    } catch (err) {
      console.error("Download generation error:", err);
      alert("ডাউনলোড ফাইল তৈরি করতে সমস্যা হয়েছে। PDF-টি অনেক বড় হতে পারে।");
      setGenerating(false);
    }
  };

  const triggerDownload = () => {
    if (!downloadUrl) return;
    const a = document.createElement("a");
    a.href = downloadUrl;
    a.download = (fileName || "flipbook") + "_offline.html";
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    // Delay removal
    setTimeout(() => {
      document.body.removeChild(a);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f0c29] via-[#302b63] to-[#24243e] text-white flex flex-col">
      {/* Header */}
      <header className="text-center pt-6 pb-2 px-4">
        <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent">
          📖 PDF ফ্লিপবুক
        </h1>
        <p className="text-gray-400 mt-1 text-sm md:text-base">
          PDF আপলোড করুন → ফ্লিপবুক দেখুন → অফলাইনে ডাউনলোড করুন
        </p>
      </header>

      {/* Upload & Download Section */}
      <div className="flex flex-col items-center gap-3 mt-4 px-4">
        <button
          onClick={() => fileInputRef.current?.click()}
          className="px-8 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 rounded-full text-lg font-semibold shadow-lg hover:shadow-purple-500/30 transition-all duration-300 hover:-translate-y-1 cursor-pointer"
        >
          📂 PDF ফাইল আপলোড করুন
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="application/pdf"
          onChange={handleFileUpload}
          className="hidden"
        />

        {pages.length > 0 && !downloadReady && (
          <button
            onClick={generateDownload}
            disabled={generating}
            className="px-8 py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 rounded-full text-lg font-semibold shadow-lg hover:shadow-green-500/30 transition-all duration-300 hover:-translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {generating
              ? "⏳ ফাইল তৈরি হচ্ছে... অপেক্ষা করুন"
              : "⬇️ অফলাইন ফ্লিপবুক তৈরি করুন"}
          </button>
        )}

        {downloadReady && downloadUrl && (
          <div className="flex flex-col items-center gap-2">
            <p className="text-green-400 text-sm">✅ ফাইল তৈরি হয়ে গেছে!</p>
            <button
              onClick={triggerDownload}
              className="px-8 py-3 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-400 hover:to-emerald-400 rounded-full text-lg font-semibold shadow-lg hover:shadow-green-500/30 transition-all duration-300 hover:-translate-y-1 cursor-pointer animate-pulse"
            >
              ⬇️ এখনই ডাউনলোড করুন
            </button>
            <a
              ref={downloadLinkRef}
              href={downloadUrl}
              download={(fileName || "flipbook") + "_offline.html"}
              className="text-blue-400 underline text-sm hover:text-blue-300 mt-1"
            >
              ডাউনলোড না হলে এখানে ক্লিক করুন
            </a>
          </div>
        )}
      </div>

      {/* Loading Progress */}
      {loading && (
        <div className="flex flex-col items-center mt-6 px-4">
          <div className="w-full max-w-md bg-gray-800 rounded-full h-4 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="mt-2 text-gray-300">
            📄 পৃষ্ঠা লোড হচ্ছে... {progress}% (
            {Math.round((progress / 100) * totalPages)}/{totalPages})
          </p>
        </div>
      )}

      {/* Flipbook Viewer */}
      {pages.length > 0 && !loading && (
        <>
          <div className="flex-1 flex items-center justify-center px-4 mt-4 relative">
            <div
              className="relative w-full max-w-3xl rounded-xl overflow-hidden shadow-2xl shadow-black/50"
              style={{ perspective: "2000px" }}
            >
              {/* Pages */}
              <div className="relative w-full" style={{ paddingBottom: "75%" }}>
                {pages.map((page, index) => (
                  <div
                    key={index}
                    className="absolute top-0 left-0 w-full h-full transition-transform duration-700 ease-in-out"
                    style={{
                      transformOrigin: "left center",
                      backfaceVisibility: "hidden",
                      zIndex: pages.length - index,
                      transform:
                        index < currentPage
                          ? "rotateY(-180deg)"
                          : "rotateY(0deg)",
                    }}
                  >
                    <img
                      src={page.dataUrl}
                      alt={`পৃষ্ঠা ${index + 1}`}
                      className="w-full h-full object-contain bg-white rounded-lg"
                    />
                  </div>
                ))}
              </div>

              {/* Touch zones */}
              <div
                className="absolute top-0 left-0 w-2/5 h-full z-20 cursor-pointer"
                onClick={prevPage}
              />
              <div
                className="absolute top-0 right-0 w-2/5 h-full z-20 cursor-pointer"
                onClick={nextPage}
              />
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-4 my-4 flex-wrap px-4">
            <button
              onClick={prevPage}
              disabled={currentPage === 0}
              className="px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 rounded-full font-semibold shadow-lg transition-all duration-300 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
            >
              ◀ আগের পৃষ্ঠা
            </button>
            <span className="text-lg font-mono bg-white/10 px-4 py-2 rounded-full min-w-[120px] text-center">
              {currentPage + 1} / {pages.length}
            </span>
            <button
              onClick={nextPage}
              disabled={currentPage === pages.length - 1}
              className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 rounded-full font-semibold shadow-lg transition-all duration-300 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
            >
              পরের পৃষ্ঠা ▶
            </button>
          </div>

          <p className="text-center text-gray-500 text-xs pb-4">
            ← → Arrow keys দিয়ে পৃষ্ঠা উল্টান | বাম/ডান পাশে ক্লিক করুন |
            মোবাইলে সোয়াইপ করুন
          </p>
        </>
      )}

      {/* Empty State */}
      {pages.length === 0 && !loading && (
        <div className="flex-1 flex items-center justify-center px-4">
          <div className="text-center p-10 rounded-2xl bg-white/5 backdrop-blur-sm border border-white/10 max-w-md w-full">
            <div className="text-6xl mb-4">📚</div>
            <h2 className="text-xl font-semibold text-gray-200 mb-2">
              কোনো PDF আপলোড করা হয়নি
            </h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              উপরের বাটনে ক্লিক করে একটি PDF ফাইল আপলোড করুন।
              <br />
              PDF ফ্লিপবুক আকারে প্রদর্শিত হবে এবং আপনি সেটি
              <br />
              <span className="text-green-400 font-semibold">
                অফলাইনে পড়ার জন্য ডাউনলোড
              </span>{" "}
              করতে পারবেন।
            </p>
            <div className="mt-6 text-left text-sm text-gray-400 space-y-2">
              <p>✅ PDF আপলোড করুন</p>
              <p>✅ ফ্লিপবুক আকারে পড়ুন</p>
              <p>✅ HTML ফাইল তৈরি ও ডাউনলোড করুন</p>
              <p>✅ অফলাইনে Chrome-এ খুলে পড়ুন</p>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="text-center py-3 text-gray-600 text-xs border-t border-white/5">
        PDF ফ্লিপবুক © {new Date().getFullYear()} — আপনার ডাটা সম্পূর্ণ
        নিরাপদ, কোনো সার্ভারে আপলোড হয় না
      </footer>
    </div>
  );
}

export default App;
